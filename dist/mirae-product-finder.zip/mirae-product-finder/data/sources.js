/* ============================================================================
 * 금융상품 통합조회 — 실데이터 연동 계층
 * ----------------------------------------------------------------------------
 * 공개 소스에서 실제 상품 데이터를 가져와 MASP 스키마로 정규화한다.
 *
 * [연동 가능 — KRX 정보데이터시스템 공개 엔드포인트]
 *   ETF   전종목 기본정보  MDCSTAT04601  종목명·코드·기초지수·운용사·총보수·상장일
 *   ETF   전종목 시세      MDCSTAT04301  종가·NAV·순자산총액·거래량
 *   ETF   전종목 등락률    MDCSTAT04401  기간 수익률 (1M/3M/6M/1Y)
 *   ETF   개별종목 시세    MDCSTAT04501  일별 시계열 (상세 열 때 지연 조회)
 *   ETN   전종목 기본정보  MDCSTAT06701 / 시세 MDCSTAT06401
 *   채권  전종목 시세      MDCSTAT09801 / 장외 채권수익률 MDCSTAT11401
 *
 *   엔드포인트·파라미터명은 pykrx(https://github.com/sharebook-kr/pykrx)에
 *   공개된 KRX 메뉴 카탈로그(path_bld_information.json)에서 확인한 값이다.
 *
 * [주 소스 — 미래에셋증권 공개 상품 API]
 *   ELS/DLS 청약목록  POST /hks/hks4022/a01.json   (로컬 서버 /api/mas 경유)
 *     상품명·상품번호·종류·위험등급·제시수익률·기초자산·청약기간·조기상환주기
 *     ·온라인청약가능·진행상태·통화·최대손실률·원금보장률
 *   엔드포인트와 파라미터명은 상품 페이지에 포함된 스크립트에서 확인한 값이다.
 *   응답은 EUC-KR 이므로 로컬 서버가 cp949 로 디코딩해 UTF-8 로 넘겨준다.
 *
 * [연동 불가 — 공개 API 부재]
 *   펀드 수익률·보수      금융투자협회 전자공시(dis.kofia.or.kr) — 공개 API 없음
 *   RP·CMA 금리           미래에셋증권 홈페이지 — 공개 API 없음
 *   랩·신탁               공개 소스 없음
 *   위험등급·세제·판매채널  KRX 공개데이터에 없음 (투자설명서 항목)
 *   => 위 항목은 사내 상품 API 또는 CSV 임포트로 채운다. 임의 생성하지 않는다.
 *
 * 브라우저에서 직접 호출하면 CORS 로 막히는 경우가 많아 프록시 폴백을 둔다.
 * 사내망에서는 PROXIES 맨 앞에 사내 프록시(예: '/api/proxy?url=')를 추가하면 된다.
 * ========================================================================== */
var MASPSRC = (function () {
  'use strict';

  var KRX_URL = 'https://data.krx.co.kr/comm/bldAttendant/getJsonData.cmd';
  var KRX_REFERER = 'https://data.krx.co.kr/contents/MDC/MDI/outerLoader/index.cmd';
  var TIMEOUT = 8000;

  /* CORS 프록시 폴백 체인 — 앞에서부터 시도하고 처음 성공한 경로를 계속 쓴다.
     serve-products.py 로 실행한 경우 로컬 프록시가 맨 앞에 붙는다. 파이썬이
     서버 대 서버로 KRX 를 호출하므로 CORS 가 발생하지 않는 유일한 확실한 경로다. */
  var PROXIES = [
    { name: '직접 호출', wrap: function (u) { return u; }, form: true },
    { name: 'corsproxy.io', wrap: function (u) { return 'https://corsproxy.io/?url=' + encodeURIComponent(u); }, form: true },
    { name: 'allorigins', wrap: function (u) { return 'https://api.allorigins.win/raw?url=' + encodeURIComponent(u); }, form: true }
  ];
  /* KRX 는 세션 쿠키(JSESSIONID) 없이 POST 하면 HTTP 400 을 준다. 브라우저는
     data.krx.co.kr 의 쿠키를 붙일 수 없으므로 '직접 호출'/공용 프록시 경로는
     사실상 실패한다. serve-products.py 가 쿠키를 들고 호출하는 유일한 경로다. */
  var LOCAL_PROXY = { name: '로컬 실행(serve-products.py)', wrap: function () { return '/api/krx'; }, form: true };
  /* http(s) 로 서비스되는 경우에만 로컬 프록시를 시도한다 (file:// 에서는 무의미) */
  if (typeof location !== 'undefined' && /^https?:$/.test(location.protocol)) {
    PROXIES.unshift(LOCAL_PROXY);
  }
  var proxyHint = 0;   /* 성공한 프록시 인덱스를 기억해 이후 요청에 먼저 사용 */

  /* 파일을 직접 열었는지(file://) 판별. 이 경우 파이썬 서버를 거치지 않으므로
     KRX 세션 쿠키를 붙일 수 없고, 실데이터는 구조적으로 들어올 수 없다.
     공용 프록시로 24초를 헛되게 쓰지 않고 사유를 바로 알린다. */
  var IS_FILE = typeof location !== 'undefined' && location.protocol === 'file:';
  function isFileMode() { return IS_FILE && !SNAP; }

  /* serve-products.py --snapshot 으로 저장한 원본 응답. 있으면 네트워크를 타지
     않고 이것을 그대로 파싱한다(같은 파서를 쓰므로 결과가 동일하다).      */
  var SNAP = (typeof window !== 'undefined' && window.MASP_SNAPSHOT) || null;
  var snapUse = {};   /* bld 별 소비 인덱스 — 같은 bld 를 여러 번 부르는 경우 대응 */
  function snapshotFor(bld) {
    if (!SNAP || !SNAP.calls) return null;
    var short = bld.split('/').pop();
    var list = SNAP.calls[short];
    if (!list || !list.length) return null;
    var i = snapUse[short] || 0;
    snapUse[short] = i + 1;
    var hit = list[Math.min(i, list.length - 1)];
    if (hit && hit.__error__) return null;
    return hit;
  }
  /* 출처 라벨 — 스냅샷을 소비했는지 실시간 조회인지 구분해 표시한다 */
  function srcLabel() { return SNAP ? ('KRX 스냅샷 ' + (SNAP.asOf || '')) : 'KRX'; }
  function snapshotInfo() {
    return SNAP ? { asOf: SNAP.asOf, source: SNAP.source || 'KRX' } : null;
  }

  /* 진단 로그 — 어떤 소스가 성공/실패했는지 화면에서 그대로 보여준다 */
  var diag = [];
  function log(entry) { diag.push(entry); return entry; }
  function getDiag() { return diag.slice(); }
  function resetDiag() { diag = []; }

  /* ------------------------------------------------------------------ HTTP */
  function withTimeout(promise, ms, onAbort) {
    return new Promise(function (resolve, reject) {
      var done = false;
      var t = setTimeout(function () {
        if (done) return;
        done = true;
        if (onAbort) try { onAbort(); } catch (e) { }
        reject(new Error('timeout ' + ms + 'ms'));
      }, ms);
      promise.then(function (v) {
        if (done) return; done = true; clearTimeout(t); resolve(v);
      }, function (e) {
        if (done) return; done = true; clearTimeout(t); reject(e);
      });
    });
  }

  /* KRX 는 form-encoded POST 로 bld + 파라미터를 받는다 */
  function krxPost(bld, params) {
    /* 스냅샷이 있으면 네트워크를 타지 않는다 */
    var snap = snapshotFor(bld);
    if (snap) {
      log({ bld: bld, proxy: '스냅샷 ' + (SNAP.asOf || ''), ok: true, msg: rowsOf(snap).length + '행' });
      return Promise.resolve(snap);
    }
    var body = new URLSearchParams();
    body.set('bld', bld);
    Object.keys(params || {}).forEach(function (k) { body.set(k, params[k]); });

    var order = PROXIES.slice(proxyHint).concat(PROXIES.slice(0, proxyHint));
    var attempt = 0;

    function tryNext() {
      if (attempt >= order.length) return Promise.reject(new Error('all proxies failed'));
      var px = order[attempt++];
      var ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
      var req = fetch(px.wrap(KRX_URL), {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
        body: body.toString(),
        signal: ctrl ? ctrl.signal : undefined
      }).then(function (r) {
        if (!r.ok) {
          /* 로컬 프록시는 실패 사유를 {"error": "..."} 로 돌려준다.
             그 내용을 그대로 진단에 노출해야 원인을 CLI 없이 알 수 있다. */
          return r.text().then(function (t) {
            var detail = '';
            try {
              var j = JSON.parse(t) || {};
              var e2 = j.error !== undefined ? j.error : j.message;
              detail = (e2 && typeof e2 === 'object') ? JSON.stringify(e2) : (e2 == null ? '' : String(e2));
            } catch (e) { detail = t.slice(0, 120); }
            throw new Error('HTTP ' + r.status + (detail ? ' | ' + detail : ''));
          });
        }
        return r.text();
      }).then(function (txt) {
        var j;
        try { j = JSON.parse(txt); }
        catch (e) { throw new Error('not JSON (' + txt.slice(0, 60) + ')'); }
        proxyHint = PROXIES.indexOf(px);
        return j;
      });
      return withTimeout(req, TIMEOUT, function () { if (ctrl) ctrl.abort(); })
        .catch(function (e) {
          var msg = String(e.message || e);
          log({ bld: bld, proxy: px.name, ok: false, msg: msg });
          /* 로컬 서버가 응답을 준 경우(HTTP 5xx 등) 그 서버가 이미 KRX 를 직접
             호출한 것이다. 공용 프록시는 쿠키·로그인을 붙일 수 없어 성공할 수
             없으므로, 요청당 24초를 낭비하지 않고 여기서 끝낸다. */
          if (px === LOCAL_PROXY && /^HTTP /.test(msg)) {
            return Promise.reject(new Error(msg));
          }
          return tryNext();
        });
    }
    return tryNext();
  }

  /* KRX 응답은 output / OutBlock_1 / block1 중 하나에 배열로 담겨 온다 */
  function rowsOf(json) {
    if (!json) return [];
    var keys = ['output', 'OutBlock_1', 'block1', 'result'];
    for (var i = 0; i < keys.length; i++) {
      var v = json[keys[i]];
      if (Array.isArray(v)) return v;
      if (v && Array.isArray(v.OutBlock_1)) return v.OutBlock_1;
    }
    for (var k in json) if (Array.isArray(json[k])) return json[k];
    return [];
  }

  /* ---------------------------------------------------------- 필드 매핑 유틸 */
  /* KRX 출력 필드명은 메뉴별로 조금씩 다르다. 후보 키를 여러 개 두고 처음
     매칭되는 값을 쓰며, 매칭 실패한 경우 진단 로그에 실제 키를 남긴다.     */
  function pick(row, cands) {
    for (var i = 0; i < cands.length; i++) {
      if (row[cands[i]] !== undefined && row[cands[i]] !== '' && row[cands[i]] !== '-') return row[cands[i]];
    }
    return null;
  }
  function n(v) {
    if (v == null) return null;
    var s = String(v).replace(/,/g, '').replace(/%/g, '').trim();
    if (s === '' || s === '-' || s === '.') return null;
    var f = parseFloat(s);
    return isNaN(f) ? null : f;
  }
  function ymd(v) {
    if (!v) return null;
    var s = String(v).replace(/[^0-9]/g, '');
    return s.length === 8 ? s.slice(0, 4) + '-' + s.slice(4, 6) + '-' + s.slice(6, 8) : null;
  }

  /* KRX 실제 출력 키를 우선 순위대로 나열한다. 메뉴마다 이름이 달라서
     (기초지수는 ETF_OBJ_IDX_NM / IDX_IND_NM, 순자산은 INVSTASST_NETASST_TOTAMT
     / LIST_MKTCAP 등) 후보를 넓게 두고, 전부 실패하면 진단에 실제 키를 남긴다. */
  var K = {
    code: ['ISU_SRT_CD', 'ISU_CD', 'ISU_SRT_CD1'],
    isin: ['ISU_CD', 'ISU_SRT_CD'],
    name: ['ISU_ABBRV', 'ISU_NM', 'ISU_KOR_ABBRV', 'ISU_KOR_NM'],
    index: ['ETF_OBJ_IDX_NM', 'IDX_IND_NM', 'BAS_IDX_NM', 'IDX_NM', 'ETN_OBJ_IDX_NM'],
    manager: ['COM_ABBRV', 'ISUR_NM', 'COM_NM'],
    fee: ['ETF_TOT_FEE', 'ETN_TOT_FEE', 'TOT_FEE', 'TOT_PAY', 'TOTL_PAY', 'CMSN_RT', 'FEE_RT'],
    listDd: ['LIST_DD', 'LIST_DT'],
    close: ['TDD_CLSPRC', 'CLSPRC', 'ISU_CLSPRC', 'TDD_CLSPRC1'],
    nav: ['NAV', 'LST_NAV', 'LAST_NAV', 'ISU_NAV'],
    netAsset: ['INVSTASST_NETASST_TOTAMT', 'NETASST_TOTAMT', 'LIST_MKTCAP', 'MKTCAP', 'NET_ASST_TOTAMT'],
    volume: ['ACC_TRDVOL', 'TRDVOL'],
    flucRt: ['FLUC_RT', 'CMPPREVDD_RT', 'FLUC_RT1'],
    ytm: ['CLSPRC_YD', 'YD', 'YD_RT', 'BND_YD', 'CLSPRC_YD1'],
    bondName: ['ISU_NM', 'ISU_ABBRV', 'BND_NM'],
    tradeDd: ['TRD_DD', 'BAS_DD']
  };

  /* 매핑 실패 진단 — 실제 응답 키를 그대로 보여줘야 수정이 빠르다 */
  function auditRow(tag, row, needed) {
    var missing = needed.filter(function (f) { return pick(row, K[f]) == null; });
    if (missing.length) {
      log({ bld: tag, ok: true, warn: 'unmapped: ' + missing.join(',') , keys: Object.keys(row).join(' ') });
    }
  }

  /* ------------------------------------------------------------------ 날짜 */
  function fmtDd(d) {
    return d.getFullYear() + ('0' + (d.getMonth() + 1)).slice(-2) + ('0' + d.getDate()).slice(-2);
  }
  /* 조회 기준일: 주말이면 직전 금요일로 당긴다 (공휴일은 응답 비면 재시도) */
  function lastBusinessDay(base) {
    var d = new Date(base.getTime());
    while (d.getDay() === 0 || d.getDay() === 6) d.setDate(d.getDate() - 1);
    return d;
  }
  function monthsAgo(base, m) {
    var d = new Date(base.getTime());
    d.setMonth(d.getMonth() - m);
    return lastBusinessDay(d);
  }

  /* 거래일이 아니면 빈 배열이 오므로 최대 5영업일 뒤로 물러나며 재시도 */
  function krxPostRetry(bld, params, dateKey, baseDate, tries) {
    tries = tries == null ? 5 : tries;
    var d = lastBusinessDay(baseDate);
    function go(left) {
      var p = {};
      Object.keys(params).forEach(function (k) { p[k] = params[k]; });
      if (dateKey) p[dateKey] = fmtDd(d);
      return krxPost(bld, p).then(function (j) {
        var rows = rowsOf(j);
        if (rows.length || left <= 0) return { rows: rows, date: fmtDd(d) };
        d.setDate(d.getDate() - 1);
        d = lastBusinessDay(d);
        return go(left - 1);
      });
    }
    return go(tries);
  }

  /* =========================================================== ETF 어댑터 */
  function loadEtf(asOfDate) {
    var base = lastBusinessDay(asOfDate);
    var periods = [
      { key: 'ret1m', m: 1 }, { key: 'ret3m', m: 3 },
      { key: 'ret6m', m: 6 }, { key: 'ret1y', m: 12 }
    ];

    return Promise.all([
      /* 1) 기본정보 — 종목명/코드/기초지수/운용사/총보수/상장일 */
      krxPost('dbms/MDC/STAT/standard/MDCSTAT04601', {}).then(rowsOf),
      /* 2) 전종목 시세 — 종가/NAV/순자산 */
      krxPostRetry('dbms/MDC/STAT/standard/MDCSTAT04301', {}, 'trdDd', base).catch(function () { return { rows: [] }; }),
      /* 3) 기간 등락률 — 실제 기간 수익률 */
      Promise.all(periods.map(function (p) {
        return krxPost('dbms/MDC/STAT/standard/MDCSTAT04401', {
          strtDd: fmtDd(monthsAgo(base, p.m)), endDd: fmtDd(base)
        }).then(rowsOf).catch(function () { return []; });
      }))
    ]).then(function (res) {
      var info = res[0], quote = res[1].rows || [], rets = res[2];
      if (!info.length) throw new Error('ETF 기본정보 응답 없음');
      auditRow('MDCSTAT04601', info[0], ['code', 'name', 'index', 'manager', 'fee']);
      if (quote.length) auditRow('MDCSTAT04301', quote[0], ['code', 'close', 'nav', 'netAsset']);

      var qByCode = {}, rByCode = [];
      quote.forEach(function (r) { var c = pick(r, K.code); if (c) qByCode[c] = r; });
      rets.forEach(function (rows, i) {
        var m = {};
        rows.forEach(function (r) { var c = pick(r, K.code); if (c) m[c] = n(pick(r, K.flucRt)); });
        rByCode[i] = m;
      });

      var out = info.map(function (r) {
        var code = pick(r, K.code);
        var q = qByCode[code] || {};
        var p = {
          cat: 'etf',
          live: true,
          source: srcLabel(),
          sourceUrl: 'https://data.krx.co.kr/contents/MDC/MDI/mdiLoader/index.cmd?menuId=MDC020103010101',
          code: String(code || ''),
          isin: String(pick(r, K.isin) || ''),
          name: [String(pick(r, K.name) || ''), String(pick(r, K.name) || '')],
          provider: [String(pick(r, K.manager) || ''), String(pick(r, K.manager) || '')],
          etfIndex: pick(r, K.index),
          etfBrand: brandOf(String(pick(r, K.name) || '')),
          fee: n(pick(r, K.fee)),
          launch: ymd(pick(r, K.listDd)),
          price: n(pick(q, K.close)),
          nav: n(pick(q, K.nav)),
          /* KRX 순자산총액은 원 단위 -> 억원으로 환산 (화면 단위와 일치) */
          aum: n(pick(q, K.netAsset)) != null ? Math.round(n(pick(q, K.netAsset)) / 1e8) : null,
          currency: 'KRW',
          status: 'sale',
          /* 아래 항목은 KRX 공개데이터에 없다 — 임의로 채우지 않고 null 로 둔다 */
          risk: null, tax: [], channel: [], minAmount: null, dist: null,
          asset: assetOf(String(pick(r, K.name) || ''), String(pick(r, K.index) || '')),
          region: regionOf(String(pick(r, K.name) || '')),
          series: null, bench: null, holdings: null
        };
        periods.forEach(function (pd, i) { p[pd.key] = rByCode[i] ? rByCode[i][code] : null; });
        p.ret3y = null;
        p.hedged = /\(H\)/.test(p.name[0]) ? 'h' : 'uh';
        return p;
      }).filter(function (p) { return p.code && p.name[0]; });

      log({ bld: 'ETF', ok: true, msg: out.length + '건 수신 (기본정보 ' + info.length + ' / 시세 ' + quote.length + ')' });
      return out;
    });
  }

  /* ETF/ETN 브랜드는 종목명 접두어로 판별 (KRX 필드에 별도 항목이 없다) */
  var BRANDS = ['TIGER', 'KODEX', 'ACE', 'RISE', 'PLUS', 'SOL', 'KOSEF', 'ARIRANG', 'HANARO', 'TIMEFOLIO', 'BNK', 'WON', 'FOCUS', 'ITF', 'KIWOOM'];
  function brandOf(name) {
    var up = name.toUpperCase();
    for (var i = 0; i < BRANDS.length; i++) if (up.indexOf(BRANDS[i]) === 0) return BRANDS[i];
    return up.split(' ')[0] || null;
  }
  /* 종목명/기초지수 문자열에서 자산유형·투자지역을 추정 (표시용 분류일 뿐) */
  function assetOf(name, index) {
    var s = name + ' ' + index;
    if (/채권|국고|통안|크레딧|회사채|만기매칭|금리|CD|KOFR|단기자금/.test(s)) return 'bd';
    if (/리츠|부동산|인프라|금|은|원유|커머디티|구리/.test(s)) return 'alt';
    if (/혼합|밸런스|TDF|타겟/.test(s)) return 'mx';
    if (/머니마켓|MMF/.test(s)) return 'mm';
    return 'eq';
  }
  function regionOf(name) {
    if (/미국|나스닥|S&P|다우|필라델피아/.test(name)) return 'us';
    if (/중국|차이나|항셍|CSI/.test(name)) return 'cn';
    if (/일본|니케이|TOPIX/.test(name)) return 'jp';
    if (/인도|니프티|NIFTY/i.test(name)) return 'in';
    if (/유럽|유로|STOXX|독일/.test(name)) return 'eu';
    if (/신흥국|이머징|베트남|인도네시아|브라질|멕시코/.test(name)) return 'em';
    if (/글로벌|선진국|세계|월드/.test(name)) return 'gl';
    return 'kr';
  }

  /* ==================================================== 미래에셋 펀드 어댑터 */
  /* 펀드찾기 화면의 검색 API. 2단계 호출이 필요해 로컬 서버가 대신 수행하고
     결과만 /api/mas-fund 로 넘겨준다.
       Field.FDN 펀드명 / KR_FD_CD·DOCID 펀드코드 / PD_CLSS 위험등급(01~06)
       M1_BNFR·M3_BNFR·M6_BNFR·M12_BNFR 기간수익률 / NASST_SUM 순자산(원)
       ONLINE_PRVT_YN 온라인 유무 / HAN_CLAS_NM 클래스명
       BF_FEE_EXP 선취수수료 / FEE_N_YN 수수료무료 / PD_TYP_CD 유형코드
     PD_TYP_CD·ADMICN(운용사) 의 코드→이름 표는 외부 JS 에 있어 아직 없다.
     없는 값을 만들지 않고 비워 둔다. */
  function loadMasFund(asOfDate) {
    var body = new URLSearchParams();
    body.set('listCount', '300');
    body.set('sort', 'NASST_SUM');
    var ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
    var req = fetch('/api/mas-fund', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
      body: body.toString(),
      signal: ctrl ? ctrl.signal : undefined
    }).then(function (r) {
      return r.text().then(function (t) {
        var j = null;
        try { j = JSON.parse(t); } catch (e) { throw new Error('JSON 아님: ' + t.slice(0, 80)); }
        if (!r.ok) throw new Error('HTTP ' + r.status + (j && j.error ? ' | ' + j.error : ''));
        return j;
      });
    });
    return withTimeout(req, 20000, function () { if (ctrl) ctrl.abort(); }).then(function (res) {
      var docs = res.docs || [];
      if (!docs.length) throw new Error('펀드 목록 없음 (mode=' + res.mode + ')');
      var out = docs.map(function (d) { return masFundRow(d.Field || d); })
        .filter(function (p) { return p && p.name[0]; });
      log({ bld: '미래에셋 펀드', ok: true, msg: out.length + '건 수신 (전체 ' + res.total + ')' });
      return out;
    });
  }

  function masFundRow(fd) {
    var nm = String(fd.FDN || '').split('\r')[0].trim();
    if (!nm) return null;
    var grade = parseInt(String(fd.PD_CLSS || '').replace(/[^0-9]/g, ''), 10);
    var nasst = n(fd.NASST_SUM);
    var cls = String(fd.HAN_CLAS_NM || '').trim();
    var online = String(fd.ONLINE_PRVT_YN || '').trim() === '1';
    return {
      cat: 'fund', live: true, source: '미래에셋증권',
      sourceUrl: 'https://securities.miraeasset.com/hks/hks4116/r01.do',
      code: String(fd.KR_FD_CD || fd.DOCID || '').trim(),
      name: [nm, nm],
      /* 운용사 코드(ADMICN)의 이름 표가 없어 비워 둔다 — 추정하지 않는다 */
      provider: ['', ''],
      className: cls,
      risk: (grade >= 1 && grade <= 6) ? grade : null,
      ret1m: n(fd.M1_BNFR), ret3m: n(fd.M3_BNFR),
      ret6m: n(fd.M6_BNFR), ret1y: n(fd.M12_BNFR), ret3y: null,
      /* NASST_SUM 은 원 단위 -> 화면 단위(억원) */
      aum: nasst != null ? Math.round(nasst / 1e8) : null,
      /* BF_FEE_EXP 는 선취수수료다. 총보수가 아니므로 fee 로 쓰지 않는다. */
      frontFee: n(fd.BF_FEE_EXP), fee: null,
      feeFree: String(fd.FEE_N_YN || '').toUpperCase() === 'Y',
      channel: online ? ['online', 'app', 'branch'] : ['branch'],
      status: 'sale', currency: 'KRW', tax: [],
      fundType: null, asset: null, region: null,
      minAmount: null, series: null, bench: null, holdings: null,
      highDifficulty: String(fd.FD_STC_CD || '') === '02',
      pick: String(fd.PBFF_FD_UNVS_YN || '').toUpperCase() === 'Y'
    };
  }

  /* ================================================== 미래에셋 ELS/DLS 어댑터 */
  /* 미래에셋증권 공개 상품 API. 로컬 서버(serve-products.py)의 /api/mas 를 경유한다.
     엔드포인트·파라미터는 상품 페이지에 포함된 스크립트에서 확인한 값이다.
       POST /hks/hks4022/a01.json
       grid01[] : itm_nm 상품명 / itm_no 상품번호 / omkt_drvs_pcd_nm 종류
                  omkt_drvs_risk_gcd 위험등급 / omkt_drv_frcs_ern_r 제시수익률
                  uast_cn 기초자산 / apy_strt_dt~apy_end_dt 청약기간
                  omkt_drv_exrt_cycl_cn 조기상환주기 / onln_apy_abl_yn 온라인청약
                  prgs_stat_nm 진행상태 / curr_cd_nm 통화 / max_abl_los_r 최대손실률
     이 소스는 '보조' 가 아니라 주 소스다(미래에셋이 발행하는 실제 상품). */
  function masPost(path, params, ref) {
    var body = new URLSearchParams();
    body.set('__path', path);
    if (ref) body.set('__ref', ref);
    Object.keys(params || {}).forEach(function (k) { body.set(k, params[k]); });
    var ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
    var req = fetch('/api/mas', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
      body: body.toString(),
      signal: ctrl ? ctrl.signal : undefined
    }).then(function (r) {
      return r.text().then(function (t) {
        var j = null;
        try { j = JSON.parse(t); } catch (e) { throw new Error('JSON 아님: ' + t.slice(0, 80)); }
        if (!r.ok) throw new Error('HTTP ' + r.status + (j && j.error ? ' | ' + j.error : ''));
        return j;
      });
    });
    return withTimeout(req, 15000, function () { if (ctrl) ctrl.abort(); });
  }

  function ymd8(v) {
    var t = String(v == null ? '' : v).replace(/[^0-9]/g, '');
    return t.length === 8 ? t.slice(0, 4) + '-' + t.slice(4, 6) + '-' + t.slice(6, 8) : null;
  }
  function daysUntil(iso, todayIso) {
    if (!iso) return null;
    var a = new Date(iso + 'T00:00:00Z').getTime(), b = new Date(todayIso + 'T00:00:00Z').getTime();
    if (isNaN(a) || isNaN(b)) return null;
    return Math.round((a - b) / 86400000);
  }
  /* 미래에셋 상품종류명 -> 화면 유형코드 */
  function elsTypeOf(nm) {
    var t = String(nm || '');
    if (/ELB|DLB|원금\s*지급|원금\s*보장/.test(t)) return 'elb';
    if (/DLS/.test(t)) return 'dls';
    if (/월지급/.test(t)) return 'month';
    if (/리자드/.test(t)) return 'lizard';
    return 'step';
  }
  /* 기초자산 문자열 -> 화면 기초자산 코드 목록 */
  var UAST_MAP = [
    [/KOSPI\s*200|코스피\s*200|\bK2001\b/i, 'KOSPI200'], [/S&P\s*500|SPX/i, 'SPX'],
    [/EUROSTOXX|EURO\s*STOXX|SX5E/i, 'SX5E'], [/HSCEI|항셍/i, 'HSCEI'],
    [/NIKKEI|니케이|NKY/i, 'NKY'], [/NVIDIA|엔비디아/i, 'NVDA'],
    [/TESLA|테슬라/i, 'TSLA'], [/APPLE|애플/i, 'AAPL'],
    [/CMS|금리/i, 'CMS'], [/WTI|원유/i, 'WTI']
  ];
  function uastCodes(text) {
    var t = String(text || ''), out = [];
    UAST_MAP.forEach(function (p) { if (p[0].test(t) && out.indexOf(p[1]) < 0) out.push(p[1]); });
    return out;
  }

  function loadMasEls(asOfDate) {
    var today = fmtIso(asOfDate);
    var plus60 = new Date((asOfDate || new Date()).getTime() + 60 * 86400000);
    return masPost('/hks/hks4022/a01.json', {
      omkt_drvs_tcd: '',
      qry_strt_dt: today.replace(/-/g, ''),
      /* 당일~+60일로 조회해야 청약 예정 상품까지 나온다(실측 확인) */
      qry_end_dt: fmtIso(plus60).replace(/-/g, ''),
      next_key: '', dlbr_term_yn: '0', qry_sort_tp: '0', qry_sort_sqn: '0'
    }, '/hks/hks4022/n01.do').then(function (res) {
      var rows = res.grid01 || [];
      if (!rows.length) {
        throw new Error('청약 목록 없음 (message=' + (res.message || res.returnCode) + ')');
      }
      var out = rows.map(function (r) { return masElsRow(r, today); })
        .filter(function (p) { return p.name[0]; });
      log({ bld: '미래에셋 ELS/DLS', ok: true, msg: out.length + '건 수신' });
      return out;
    });
  }

  /* 실제 응답 필드 기준 매핑 (--mas-probe 로 확인한 값)
       tmod_nm  종목명 "(ELS)38031"      omkt_drvs_tcd 1.ELS 2.DLS 3.ELB 4.DLB
       omkt_drv_frcs_ern_r 제시수익률    rmnd_dys 청약 잔여일수
       apy_strt_dt~apy_end_dt 청약기간   kni_yn 낙인 여부(Y/N)
       lwrk_bar_rt 최저 배리어율          max_abl_los_r 최대손실률(음수)
       onln_apy_abl_yn 온라인청약 가능    curr_cd 통화
       omkt_drv_rpy_cycl_cn 상환주기      omkt_drv_desc_cn 상품 설명
       ofr_lmt_a 모집한도                 hlv_fn_ivst_pd_yn 고위험 여부
     위험등급은 이 응답에 없으므로 채우지 않는다. */
  var MAS_TCD = { '1': 'step', '2': 'dls', '3': 'elb', '4': 'elb' };
  function masElsRow(r, today) {
    var raw = String(pick(r, ['tmod_nm', 'itm_nm', 'omkt_drvs_pcd_nm']) || '').trim();
    /* "(ELS)38031" 형태를 읽기 쉽게 재배열한다. 원문에 있는 정보만 쓰고 덧붙이지 않는다. */
    var m = raw.match(/^\(([A-Z]+)\)\s*(\d+)$/);
    var nm = m ? ('제' + m[2] + '회 ' + m[1]) : raw;
    var tcd = String(r.omkt_drvs_tcd || '').trim();
    var kni = String(r.kni_yn || '').trim().toUpperCase();
    var bar = n(r.lwrk_bar_rt);
    var loss = n(r.max_abl_los_r);
    var dleft = n(r.rmnd_dys);
    var end = ymd8(pick(r, ['apy_end_dt', 'dlbr_obj_apy_end_dt']));
    var online = String(r.onln_apy_abl_yn || '').toUpperCase() === 'Y';
    var desc = String(r.omkt_drv_desc_cn || '').trim();
    var codes = uastCodes(desc + ' ' + [r.row1_cn, r.row2_cn, r.row3_cn].join(' '));
    return {
      cat: 'els', live: true, source: '미래에셋증권',
      sourceUrl: 'https://securities.miraeasset.com/hks/hks4022/n01.do',
      code: String(pick(r, ['omkt_drvs_pcd']) || (nm.match(/\d{3,}/) || [''])[0] || '').trim(),
      name: [nm, nm], rawName: raw,
      provider: ['미래에셋증권', 'Mirae Asset Securities'],
      elsType: MAS_TCD[tcd] || (/DLS|DLB/.test(nm) ? 'dls' : /ELB/.test(nm) ? 'elb' : 'step'),
      underlying: codes,
      uastText: desc,
      coupon: n(r.omkt_drv_frcs_ern_r),
      /* 낙인 여부가 실제로 오므로 여기서는 단정해도 된다 */
      knockIn: kni === 'Y' ? (bar != null ? bar : null) : null,
      knockInKnown: kni === 'Y' || kni === 'N',
      barrier: bar,
      maxLoss: loss != null ? Math.abs(loss) : null,
      risk: null,
      subStart: ymd8(r.apy_strt_dt), subEnd: end,
      deadlineD: dleft != null ? dleft : daysUntil(end, today),
      status: (dleft != null && dleft <= 7) ? 'closing' : 'open',
      currency: /USD|\$|미국/.test(String(r.curr_cd || '')) ? 'USD' : 'KRW',
      channel: online ? ['online', 'app', 'branch'] : ['branch'],
      tax: [], asset: 'der', region: codes.indexOf('KOSPI200') >= 0 ? 'kr' : 'gl',
      earlyText: String(r.omkt_drv_rpy_cycl_cn || '').trim(),
      offerLimit: n(r.ofr_lmt_a),
      highRisk: String(r.hlv_fn_ivst_pd_yn || '').toUpperCase() === 'Y',
      minAmount: null, fee: null, aum: null,
      series: null, bench: null, holdings: null
    };
  }

  function fmtIso(d) {
    d = d || new Date();
    return d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2) + '-' + ('0' + d.getDate()).slice(-2);
  }

  /* =========================================================== ETN 어댑터 */
  function loadEtn(asOfDate) {
    var base = lastBusinessDay(asOfDate);
    return Promise.all([
      krxPost('dbms/MDC/STAT/standard/MDCSTAT06701', {}).then(rowsOf).catch(function () { return []; }),
      krxPostRetry('dbms/MDC/STAT/standard/MDCSTAT06401', {}, 'trdDd', base).catch(function () { return { rows: [] }; })
    ]).then(function (res) {
      var info = res[0], quote = res[1].rows || [];
      var src = info.length ? info : quote;
      if (!src.length) throw new Error('ETN 응답 없음');
      auditRow('MDCSTAT06701', src[0], ['code', 'name']);
      var qByCode = {};
      quote.forEach(function (r) { var c = pick(r, K.code); if (c) qByCode[c] = r; });
      var out = src.map(function (r) {
        var code = pick(r, K.code), q = qByCode[code] || r;
        var nm = String(pick(r, K.name) || '');
        return {
          cat: 'etf', live: true, source: srcLabel(),
          sourceUrl: 'https://data.krx.co.kr/contents/MDC/MDI/mdiLoader/index.cmd?menuId=MDC020103020101',
          code: String(code || ''), name: [nm, nm],
          provider: [String(pick(r, K.manager) || ''), String(pick(r, K.manager) || '')],
          etfIndex: pick(r, K.index), etfBrand: brandOf(nm),
          fee: n(pick(r, K.fee)), launch: ymd(pick(r, K.listDd)),
          price: n(pick(q, K.close)), nav: n(pick(q, K.nav)),
          aum: n(pick(q, K.netAsset)) != null ? Math.round(n(pick(q, K.netAsset)) / 1e8) : null,
          currency: 'KRW', status: 'sale',
          risk: null, tax: [], channel: [], minAmount: null, dist: null,
          asset: assetOf(nm, ''), region: regionOf(nm),
          ret1m: null, ret3m: null, ret6m: null, ret1y: null, ret3y: null,
          hedged: /\(H\)/.test(nm) ? 'h' : 'uh',
          series: null, bench: null, holdings: null
        };
      }).filter(function (p) { return p.code && p.name[0]; });
      log({ bld: 'ETN', ok: true, msg: out.length + '건 수신' });
      return out;
    });
  }

  /* ========================================================== 채권 어댑터 */
  function loadBond(asOfDate) {
    var base = lastBusinessDay(asOfDate);
    return krxPostRetry('dbms/MDC/STAT/standard/MDCSTAT09801', {}, 'trdDd', base).then(function (r) {
      var rows = r.rows;
      if (!rows.length) throw new Error('채권 전종목 시세 응답 없음');
      auditRow('MDCSTAT09801', rows[0], ['code', 'bondName', 'close']);
      var out = rows.map(function (row) {
        var nm = String(pick(row, K.bondName) || '');
        return {
          cat: 'bond', live: true, source: srcLabel(),
          sourceUrl: 'https://data.krx.co.kr/contents/MDC/MDI/mdiLoader/index.cmd?menuId=MDC020402010101',
          code: String(pick(row, K.code) || ''), name: [nm, nm],
          provider: [nm.split(/[0-9(]/)[0].trim(), nm.split(/[0-9(]/)[0].trim()],
          price: n(pick(row, K.close)), ytm: n(pick(row, K.ytm)),
          currency: 'KRW', status: 'sale', asset: 'bd', region: 'kr',
          bondType: bondTypeOf(nm),
          /* 신용등급·잔존만기·표면금리·이자지급주기는 이 응답에 없다 */
          rating: null, residualY: null, coupon: null, cycle: null, maturity: null,
          risk: null, tax: [], channel: [], minAmount: null, aum: null,
          series: null, bench: null, holdings: null
        };
      }).filter(function (p) { return p.code && p.name[0]; });
      log({ bld: '채권', ok: true, msg: out.length + '건 수신' });
      return out;
    });
  }
  function bondTypeOf(nm) {
    if (/국고|국민주택|재정증권/.test(nm)) return 'gov';
    if (/통안|지역개발|도시철도|지방/.test(nm)) return 'muni';
    if (/카드|캐피탈|할부|리스/.test(nm)) return 'card';
    if (/조건부자본|신종자본|후순위/.test(nm)) return 'sub';
    return 'corp';
  }

  /* ETF 개별 시계열 — 상세 패널 열 때만 조회 (전체 선조회는 요청 수가 과도) */
  function loadSeries(isin, asOfDate) {
    if (!isin) return Promise.reject(new Error('ISIN 없음'));
    var base = lastBusinessDay(asOfDate);
    return krxPost('dbms/MDC/STAT/standard/MDCSTAT04501', {
      strtDd: fmtDd(monthsAgo(base, 12)), endDd: fmtDd(base), isuCd: isin, isin: isin
    }).then(function (j) {
      var rows = rowsOf(j);
      if (!rows.length) throw new Error('시계열 응답 없음');
      /* KRX 는 최신일이 먼저 오므로 오름차순으로 되돌린다 */
      var pts = rows.map(function (r) {
        return { d: ymd(pick(r, K.tradeDd)), v: n(pick(r, K.close)) };
      }).filter(function (x) { return x.d && x.v != null; }).sort(function (a, b) {
        return a.d < b.d ? -1 : 1;
      });
      if (!pts.length) throw new Error('시계열 파싱 실패');
      /* 13포인트(월 단위)로 리샘플 — 화면 차트/스파크라인 규격에 맞춘다 */
      var out = [], step = (pts.length - 1) / 12;
      for (var i = 0; i <= 12; i++) out.push(pts[Math.round(i * step)].v);
      return out;
    });
  }

  /* ====================================================== CSV / JSON 임포트 */
  /* 공개 소스가 없는 상품군(펀드·ELS·RP·랩·연금)은 사내 데이터를 파일로 받는다.
     헤더명은 한/영 모두 인식한다. 알 수 없는 컬럼은 무시한다.              */
  var CSV_MAP = {
    '상품군': 'cat', 'category': 'cat',
    '상품명': 'name', 'name': 'name', 'product': 'name',
    '상품코드': 'code', 'code': 'code',
    '운용사': 'provider', '발행사': 'provider', 'provider': 'provider',
    '위험등급': 'risk', 'risk': 'risk',
    '판매상태': 'status', 'status': 'status',
    '통화': 'currency', 'currency': 'currency',
    '최소가입금액': 'minAmount', 'minimum': 'minAmount',
    '총보수': 'fee', 'fee': 'fee',
    '일임보수': 'mgmtFee', '신탁보수': 'mgmtFee',
    '설정액': 'aum', '순자산': 'aum', 'aum': 'aum',
    '1개월': 'ret1m', '3개월': 'ret3m', '6개월': 'ret6m', '1년': 'ret1y', '3년': 'ret3y',
    '제시수익률': 'coupon', 'coupon': 'coupon',
    '최초배리어': 'barrier', 'barrier': 'barrier',
    '낙인': 'knockIn', 'knockin': 'knockIn',
    '만기': 'maturityM', 'maturity': 'maturityM',
    '청약마감': 'subEnd',
    '매매수익률': 'ytm', 'ytm': 'ytm',
    '신용등급': 'rating', 'rating': 'rating',
    '잔존기간': 'residualY',
    '약정수익률': 'rate', 'rate': 'rate',
    '약정기간': 'termD',
    '기초자산': 'underlying', 'underlying': 'underlying',
    '기초지수': 'etfIndex',
    '세제혜택': 'tax', '판매채널': 'channel', '투자지역': 'region', '자산유형': 'asset'
  };
  var CAT_ALIAS = {
    '펀드': 'fund', 'fund': 'fund', 'funds': 'fund',
    'etf': 'etf', 'etn': 'etf', 'etf·etn': 'etf',
    'els': 'els', 'dls': 'els', 'els·dls': 'els', 'elb': 'els',
    '채권': 'bond', 'bond': 'bond',
    'rp': 'rp', 'cma': 'rp', 'rp·cma': 'rp',
    '랩': 'wrap', '신탁': 'wrap', '랩·신탁': 'wrap', 'wrap': 'wrap',
    '연금': 'pension', 'irp': 'pension', 'isa': 'pension', '연금·절세': 'pension'
  };

  /* 따옴표·줄바꿈을 포함한 CSV 를 정확히 분해한다 */
  function parseCsv(text) {
    text = text.replace(/^﻿/, '');
    var rows = [], row = [], cur = '', q = false;
    for (var i = 0; i < text.length; i++) {
      var c = text[i];
      if (q) {
        if (c === '"') { if (text[i + 1] === '"') { cur += '"'; i++; } else q = false; }
        else cur += c;
      } else if (c === '"') q = true;
      else if (c === ',') { row.push(cur); cur = ''; }
      else if (c === '\n') { row.push(cur); rows.push(row); row = []; cur = ''; }
      else if (c !== '\r') cur += c;
    }
    if (cur !== '' || row.length) { row.push(cur); rows.push(row); }
    return rows.filter(function (r) { return r.some(function (c) { return String(c).trim() !== ''; }); });
  }

  function fromCsv(text) {
    var rows = parseCsv(text);
    if (rows.length < 2) throw new Error('데이터 행이 없습니다');
    var head = rows[0].map(function (h) { return String(h).trim(); });
    var keys = head.map(function (h) {
      return CSV_MAP[h] || CSV_MAP[h.toLowerCase()] || null;
    });
    if (keys.indexOf('name') < 0) {
      throw new Error('필수 컬럼 "상품명"(name) 을 찾을 수 없습니다. 헤더: ' + head.join(', '));
    }
    var NUM = ['risk', 'minAmount', 'fee', 'mgmtFee', 'aum', 'ret1m', 'ret3m', 'ret6m', 'ret1y',
      'ret3y', 'coupon', 'barrier', 'knockIn', 'maturityM', 'ytm', 'residualY', 'rate', 'termD'];
    var LIST = ['tax', 'channel', 'underlying'];
    var out = [];
    for (var r = 1; r < rows.length; r++) {
      var p = { live: true, source: 'CSV', tax: [], channel: [] };
      rows[r].forEach(function (cell, ci) {
        var k = keys[ci];
        if (!k) return;
        var v = String(cell).trim();
        if (v === '') return;
        if (k === 'cat') p.cat = CAT_ALIAS[v.toLowerCase()] || v;
        else if (k === 'name' || k === 'provider') p[k] = [v, v];
        else if (NUM.indexOf(k) >= 0) p[k] = n(v);
        else if (LIST.indexOf(k) >= 0) p[k] = v.split(/[;|/]/).map(function (s) { return s.trim(); }).filter(Boolean);
        else p[k] = v;
      });
      if (!p.name) continue;
      if (!p.cat) p.cat = 'fund';
      if (!p.code) p.code = 'CSV' + (r);
      if (!p.currency) p.currency = 'KRW';
      if (!p.status) p.status = 'sale';
      out.push(p);
    }
    if (!out.length) throw new Error('변환된 상품이 없습니다');
    log({ bld: 'CSV', ok: true, msg: out.length + '건 임포트' });
    return out;
  }

  /* ================================================================= 총괄 */
  /* 소스별로 독립 실행 — 하나가 실패해도 나머지는 반영한다 */
  /* KRX 는 '보조' 소스다. 시장 전체 상장 ETF/ETN/채권 시세를 주지만,
     이 화면의 본질인 '미래에셋증권이 판매·발행하는 상품 라인업'은 제공하지 않는다.
     주 소스는 사내 상품 API 또는 CSV 임포트이며, KRX 미연결은 오류가 아니다. */
  var CATALOG = [
    /* 주 소스: 미래에셋증권이 판매·발행하는 실제 상품 */
    { id: 'masFund', label: ['펀드 (미래에셋 펀드찾기)', 'Funds (Mirae Asset finder)'],
      cats: ['fund'], run: loadMasFund },
    { id: 'masEls', label: ['ELS·DLS (미래에셋 청약)', 'ELS/DLS (Mirae Asset offerings)'],
      cats: ['els'], run: loadMasEls },
    { id: 'etf', label: ['ETF (KRX 전종목)', 'ETF (KRX all listings)'], cats: ['etf'], aux: true, run: loadEtf },
    { id: 'etn', label: ['ETN (KRX 전종목)', 'ETN (KRX all listings)'], cats: ['etf'], aux: true, run: loadEtn },
    { id: 'bond', label: ['채권 (KRX 전종목 시세)', 'Bonds (KRX all listings)'], cats: ['bond'], aux: true, run: loadBond }
  ];
  /* 보조 소스가 담당하는 상품군 — 실패해도 '연결 실패' 가 아니라 '미연결(선택)' 이다 */
  function auxCats() {
    var out = {};
    CATALOG.forEach(function (s) { if (s.aux) s.cats.forEach(function (c) { out[c] = true; }); });
    return out;
  }
  /* 공개 소스가 없는 상품군 — 화면에 사유를 그대로 표시한다 */
  var NO_SOURCE = {
    rp: ['공개 API 없음 (발행사 홈페이지 전용)', 'No public API (issuer site only)'],
    wrap: ['공개 소스 없음', 'No public source'],
    pension: ['공개 API 없음', 'No public API']
  };

  /* 로컬 서버가 붙어 있으면 그 빌드 표시를 진단에 남긴다 (구버전 실행 구분용) */
  function probeServer() {
    if (typeof location === 'undefined' || !/^https?:$/.test(location.protocol)) return Promise.resolve();
    return fetch('/api/health').then(function (r) { return r.ok ? r.json() : null; }).then(function (j) {
      if (j) log({ bld: '로컬 서버', proxy: 'serve-products.py', ok: true, msg: '빌드 ' + (j.build || '(표시 없음 — 구버전)') });
    }).catch(function () {
      log({ bld: '로컬 서버', proxy: '-', ok: false, msg: '로컬 서버 없음 (파일을 직접 열었거나 서버 미실행)' });
    });
  }

  function loadAll(asOfDate, onEach) {
    resetDiag();
    var results = {};
    if (isFileMode()) {
      var why = 'HTML 파일을 직접 열었습니다. 실데이터는 로컬 서버로 접속해야 들어옵니다 '
              + '(run-products.bat 실행 후 http://127.0.0.1:8800 접속).';
      log({ bld: '실행 방식', proxy: 'file://', ok: false, msg: why });
      CATALOG.forEach(function (s) { results[s.id] = { ok: false, rows: [], ms: 0, error: why }; });
      return Promise.resolve(results);
    }
    return probeServer().then(function () {
    return Promise.all(CATALOG.map(function (s) {
      var t0 = Date.now();
      return s.run(asOfDate).then(function (rows) {
        results[s.id] = { ok: true, rows: rows, ms: Date.now() - t0 };
        if (onEach) onEach(s.id, results[s.id]);
      }).catch(function (e) {
        results[s.id] = { ok: false, rows: [], ms: Date.now() - t0, error: String(e.message || e) };
        log({ bld: s.id, ok: false, msg: String(e.message || e) });
        if (onEach) onEach(s.id, results[s.id]);
      });
    })).then(function () { return results; });
    });
  }

  return {
    loadAll: loadAll,
    loadSeries: loadSeries,
    fromCsv: fromCsv,
    parseCsv: parseCsv,
    getDiag: getDiag,
    snapshotInfo: snapshotInfo,
    isFileMode: isFileMode,
    auxCats: auxCats,
    CATALOG: CATALOG,
    NO_SOURCE: NO_SOURCE,
    PROXIES: PROXIES,
    _internal: { krxPost: krxPost, rowsOf: rowsOf, pick: pick, K: K, n: n, ymd: ymd, fmtDd: fmtDd }
  };
})();
