#!/usr/bin/env python3
"""products.html + data/products.js -> products-standalone.html

`products.html` 은 data/*.js 를 외부에서 로드하므로 로컬 서버가 필요하다.
이 스크립트는 스크립트 태그를 인라인해 파일 프로토콜(더블클릭)로도 열리는
단일 파일 산출물을 만든다. 소스를 수정한 뒤 다시 실행하면 된다.

    python3 build-products-standalone.py
"""
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parent
SRC = ROOT / "products.html"
OUT = ROOT / "products-standalone.html"
# products.html 이 외부 로드하는 스크립트 전부를 인라인한다
SCRIPTS = ["data/products.js", "data/krx-snapshot.js", "data/sources.js"]
# 스냅샷은 선택 사항 — 없으면 태그만 제거한다
OPTIONAL = {"data/krx-snapshot.js"}

html = SRC.read_text(encoding="utf-8")

for rel in SCRIPTS:
    tag = '<script src="%s"></script>' % rel
    if tag not in html:
        sys.exit("script tag not found in products.html: " + tag)
    if rel in OPTIONAL and not (ROOT / rel).exists():
        html = html.replace(tag, "<!-- %s 없음: 스냅샷 미포함 -->" % rel)
        print("  skip %s (파일 없음)" % rel)
        continue
    js = (ROOT / rel).read_text(encoding="utf-8")
    # </script> 가 데이터 안에 있으면 인라인 스크립트가 조기 종료된다 — 방어적으로 검사
    if "</script" in js.lower():
        sys.exit("%s contains a closing script tag; cannot inline safely" % rel)
    html = html.replace(tag, "<!-- inlined from %s -->\n<script>\n%s\n</script>" % (rel, js))

if 'script src="data/' in html:
    sys.exit("an external data script remains un-inlined")

OUT.write_text(html, encoding="utf-8")
print("wrote %s (%.0f KB)" % (OUT.name, OUT.stat().st_size / 1024))
